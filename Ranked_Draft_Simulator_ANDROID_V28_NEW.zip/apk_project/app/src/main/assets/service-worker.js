const CACHE='ranked-draft-v26';
const IMAGE_CACHE='ranked-draft-images-v26';
const CORE=['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE).catch(()=>{})))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>![CACHE,IMAGE_CACHE].includes(k)).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method!=='GET')return;
 // Keep external API/image requests available offline when they were previously fetched.
 if(u.origin!==location.origin){
  if(/\.(png|jpg|jpeg|webp|gif)(\?|$)/i.test(u.pathname) || u.hostname.includes('brawlapi.com')){
   e.respondWith(caches.open(IMAGE_CACHE).then(c=>c.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{if(r.ok)c.put(e.request,r.clone());return r}).catch(()=>new Response('',{status:504})))));
  }
  return;
 }
 if(u.pathname.endsWith('/index.html')||u.pathname==='/'||u.pathname.endsWith('/')){
  e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match(e.request).then(r=>r||caches.match('./index.html'))));
  return;
 }
 e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r})));
});
