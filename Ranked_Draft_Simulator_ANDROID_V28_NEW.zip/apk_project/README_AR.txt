مشروع Android مستقل للعبة Ranked Draft Simulator - نسخة v28 Smooth.
هذا المشروع لا يعتمد على مشروع GitHub القديم.
لبناء APK: ارفع محتويات هذا المشروع إلى مستودع GitHub جديد، ثم استخدم GitHub Actions.
